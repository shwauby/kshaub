<?php if (!defined('ABSPATH')) { exit; } ?>
<div class="wrap">
<p class="danger" style="color:#F00"><strong><?php  _e('Note: These are demo screenshots. Please buy File Manager pro to Logs functions.', 'wp-file-manager'); ?></strong>
<a href="https://filemanagerpro.io/product/file-manager" class="button button-primary" target="_blank" title="Click to Buy PRO"><?php  _e('Buy PRO', 'wp-file-manager'); ?></a></p>
<h3><?php  _e('Edit Files Logs', 'wp-file-manager'); ?></h3>	
<img src="https://www.webdesi9.com/plugins/wp_file_manager/images/logs-001.jpg">
<h3><?php  _e('Download Files Logs', 'wp-file-manager'); ?></h3>	
<img src="https://www.webdesi9.com/plugins/wp_file_manager/images/logs-002.jpg">
<h3><?php  _e('Upload Files Logs', 'wp-file-manager'); ?></h3>		
<img src="https://www.webdesi9.com/plugins/wp_file_manager/images/logs-003.jpg">
</div>